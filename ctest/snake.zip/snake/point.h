// point.h
// 

#ifndef _POINT_H_
#define _POINT_H_

#include <iostream>

typedef struct _point {
    int row;
    int col;
} CPoint, *PCPoint;


#endif /* _POINT_H_ */


