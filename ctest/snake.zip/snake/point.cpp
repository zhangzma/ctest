// point.cpp
// 
#include "point.h"
